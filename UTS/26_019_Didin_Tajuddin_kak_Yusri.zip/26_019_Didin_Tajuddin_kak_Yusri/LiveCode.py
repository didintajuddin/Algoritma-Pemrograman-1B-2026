tiket = 0
regular = 0
vip = 0
vvip = 0

while True:
    input(tiket("Masukan Nominal: "))
    if tiket == 40000:
        regular = 40000
    elif tiket == 75000:
        vip = 75000
    elif tiket == 100000:
        vvip = 100000
    else:
        print("Nominal salah")